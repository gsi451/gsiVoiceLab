# 노트북의 실시간 음성을 계속해서 입력 받아서 왼쪽 상단에 출력해준다.
# 아 테스트는 이 가능을 사용해서 계속해서 음성을 입력 받고
# 그 음성 중에서 원하는 부분들을 자동화에 사용가능할 거 같다.

# 이 프로그램은 노트북이 실행되면 자동으로 파이썬이 실행 되도록 처리해서 계속해서 테스트를 진행한다.
# chmod +x /Users/sonbyeong-ug/pythonWork/gsivoice2txt/start_gsivoice2txt.command


import speech_recognition as sr
import tkinter as tk
from threading import Thread
import datetime

# 로그 파일 기록 함수
LOG_FILE = "speech_log.txt"


def log_speech(text):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {text}\n")

# 팝업 메시지 설정
def show_popup(text):
    popup = tk.Toplevel(root)
    popup.overrideredirect(True)  # 창의 타이틀바 제거
    popup.geometry(f"+{POPUP_X}+{POPUP_Y}")  # 위치 설정
    label = tk.Label(popup, text=text, font=("Arial", 16), bg="black", fg="white", padx=10, pady=5)
    label.pack()
    popup.after(2000, popup.destroy)  # 2초 후 자동 닫힘

# 음성 인식 실행
def recognize_speech():
    recognizer = sr.Recognizer()
    mic = sr.Microphone()

    with mic as source:
        print("음성 인식 시작...")
        recognizer.adjust_for_ambient_noise(source)

        while True:
            try:
                #print("듣는 중...")
                audio = recognizer.listen(source)
                text = recognizer.recognize_google(audio, language="ko-KR")
                print(f"> {text}")
                root.after(0, show_popup, text)  # GUI에서 팝업 실행
                log_speech(text)  # 로그 파일 기록

            except sr.UnknownValueError:
                #print("음성을 인식할 수 없습니다.")
                pass  # 아무 처리도 하지 않음
            except sr.RequestError as e:
                print(f"Sphinx 오류 발생: {e}")

# Tkinter GUI 설정
root = tk.Tk()
root.withdraw()  # 메인 창 숨김

# 팝업 위치 설정 (좌상단 / 우상단 변경 가능)
POPUP_X = 50  # 왼쪽 상단: 50 / 오른쪽 상단: 화면 너비 - 200
POPUP_Y = 50  # 위쪽 위치 고정

# 음성 인식 쓰레드 실행
speech_thread = Thread(target=recognize_speech, daemon=True)
speech_thread.start()

# Tkinter 실행
root.mainloop()

import sounddevice as sd
import numpy as np
import tkinter as tk
from threading import Thread
import subprocess
import os
import vosk
import json

# pip install vosk

# 다운로드 받은 모델 폴더 경로 (예: "vosk-model-small-ko-0.22")
model_path = "vosk-model-small-ko-0.22"
if not os.path.exists(model_path):
    print("모델이 존재하지 않습니다. 모델을 다운로드 받으세요.")
    exit(1)

model = vosk.Model(model_path)

# Tkinter 설정
root = tk.Tk()
root.withdraw()

POPUP_X = 50  # 왼쪽 상단 위치
POPUP_Y = 50

def show_popup(text):
    popup = tk.Toplevel(root)
    popup.overrideredirect(True)
    popup.geometry(f"+{POPUP_X}+{POPUP_Y}")
    label = tk.Label(popup, text=text, font=("Arial", 14), bg="black", fg="white", padx=10, pady=5)
    label.pack()
    popup.after(2000, popup.destroy)  # 2초 후 자동 닫힘

def show_mac_notification(text):
    script = f'display notification "{text}" with title "알림"'
    subprocess.run(["osascript", "-e", script])

def record_audio():
    print("듣는 중...")
    # 5초 동안 녹음 (샘플레이트 16000, mono, int16)
    audio = sd.rec(int(5 * 16000), samplerate=16000, channels=1, dtype='int16')
    sd.wait()
    return audio

def recognize_speech():
    while True:
        audio_data = record_audio()
        # 매 청크마다 새로운 recognizer 생성 (상태 초기화를 위해)
        recognizer = vosk.KaldiRecognizer(model, 16000)
        data_bytes = audio_data.tobytes()
        if recognizer.AcceptWaveform(data_bytes):
            result = recognizer.Result()
            result_json = json.loads(result)
            text = result_json.get("text", "")
            print(f"입력된 음성: {text}")
            # 팝업 대신 Mac 알림으로 표시 (원하는 방식 사용)
            root.after(0, show_mac_notification, text)
        else:
            partial_result = recognizer.PartialResult()
            partial_json = json.loads(partial_result)
            partial_text = partial_json.get("partial", "")
            print("부분 결과:", partial_text)

# 음성 인식 스레드 실행
speech_thread = Thread(target=recognize_speech, daemon=True)
speech_thread.start()

# Tkinter 실행
root.mainloop()

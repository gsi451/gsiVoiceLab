import speech_recognition as sr
import tkinter as tk
from threading import Thread
import datetime
import subprocess

LOG_FILE = "speech_log.txt"

def log_speech(text):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {text}\n")

def show_popup(text):
    popup = tk.Toplevel(root)
    popup.overrideredirect(True)  # 타이틀바 제거
    popup.geometry(f"+{POPUP_X}+{POPUP_Y}")  # 위치 설정
    label = tk.Label(popup, text=text, font=("Arial", 16), bg="black", fg="white", padx=10, pady=5)
    label.pack()
    popup.after(2000, popup.destroy)  # 2초 후 닫힘

def show_mac_notification(text):
    script = f'display notification "{text}" with title "알림"'
    subprocess.run(["osascript", "-e", script])

def recognize_speech():
    recognizer = sr.Recognizer()
    # 인식 속도 개선을 위한 파라미터 조정
    recognizer.pause_threshold = 0.3       # 말이 멈춘 후 짧은 시간 내에 인식 종료
    recognizer.non_speaking_duration = 0.2   # 비말 구간의 감지 시간 단축
    recognizer.dynamic_energy_threshold = False
    recognizer.energy_threshold = 300        # 환경에 따라 적절히 조정 필요

    mic = sr.Microphone()

    with mic as source:
        print("음성 인식 시작...")
        recognizer.adjust_for_ambient_noise(source, duration=1)

        while True:
            try:
                # phrase_time_limit을 설정해 짧은 구간 단위로 인식
                audio = recognizer.listen(source, phrase_time_limit=3)
                text = recognizer.recognize_google(audio, language="ko-KR")
                print(f"> {text}")
                #root.after(0, show_popup, text)
                root.after(0, show_mac_notification, text)
                log_speech(text)

            except sr.UnknownValueError:
                pass  # 인식 실패 시 아무 동작도 하지 않음
            except sr.RequestError as e:
                print(f"요청 오류 발생: {e}")
            except sr.WaitTimeoutError:
                print("⏳ [대기 시간 초과] 음성을 감지하지 못함. 다시 시도 중...")

root = tk.Tk()
root.withdraw()  # 메인 창 숨김

# 팝업 위치 설정 (좌상단)
POPUP_X = 50
POPUP_Y = 50

speech_thread = Thread(target=recognize_speech, daemon=True)
speech_thread.start()

root.mainloop()

import whisper
import sounddevice as sd
import numpy as np
import tkinter as tk
from threading import Thread
import subprocess

# pip
# brew install ffmpeg
# pip install torch torchaudio
# pip install openai-whisper
# pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu

# ffmpeg 를 설치하는데 시간이 꽤 걸림
# 파일 실행하니 다운로드를 받고 실행을 하는거같다.
# 제대로 되지 않음..

# Whisper 모델 로드(base, small, medium)
model = whisper.load_model("base")

# Tkinter 설정
root = tk.Tk()
root.withdraw()

POPUP_X = 50  # 왼쪽 상단 위치
POPUP_Y = 50

def show_popup(text):
    popup = tk.Toplevel(root)
    popup.overrideredirect(True)
    popup.geometry(f"+{POPUP_X}+{POPUP_Y}")
    label = tk.Label(popup, text=text, font=("Arial", 14), bg="black", fg="white", padx=10, pady=5)
    label.pack()
    popup.after(2000, popup.destroy)  # 2초 후 자동 닫힘

def show_mac_notification(text):
    script = f'display notification "{text}" with title "알림"'
    subprocess.run(["osascript", "-e", script])

def record_audio():
    print("듣는 중...")
    audio = sd.rec(int(5 * 16000), samplerate=16000, channels=1, dtype=np.float32)
    sd.wait()
    return np.squeeze(audio)

def recognize_speech():
    while True:
        audio_data = record_audio()
        result = model.transcribe(audio_data)
        text = result['text']
        print(f"입력된 음성: {text}")
        #root.after(0, show_popup, text)
        root.after(0, show_mac_notification, text)

# 음성 인식 스레드 실행
speech_thread = Thread(target=recognize_speech, daemon=True)
speech_thread.start()

# Tkinter 실행
root.mainloop()
